
Serial Port

http://playground.arduino.cc/Interfacing/Java

http://rxtx.qbang.org/wiki/index.php/Download

http://fizzed.com/oss/rxtx-for-java


1)

Append the directory containing rxtxSerial.dll into your PATH environment variable.

2)
You should also ensure that the RXTXcomm.jar is in your CLASSPATH.


Or


 copy rxtxSerial.dll to %JAVA_HOME%\bin,
(%JAVA_HOME% is the folder where JRE is installed on your system; e.g. c:\Program Files\Java\j2re1.4.1_01)
 copy RXTXcomm.jar to %JAVA_HOME%\lib\ext
 
 